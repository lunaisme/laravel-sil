

<?php $__env->startSection('main-content'); ?>
    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?php echo e(__('Recap Reagen Keluar')); ?></h1>

    <div class="row justify-content-center px-3">

    <div class="col-12 card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Data Reagen Keluar</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Tanggal</th>
                            <th>Kode Barang</th>
                            <th>Nama Barang</th>
                            <th>Jumlah Keluar</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $reagenKeluar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keluar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($keluar->created_at->format('d-m-Y')); ?></td>
                                <td><?php echo e($keluar->reagen->kode); ?></td>
                                <td><?php echo e($keluar->reagen->nama); ?></td>
                                <td><?php echo e($keluar->jumlah); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="4" class="text-center">Belum ada data reagen keluar</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="form-group mt-3">
                <label for="entries">Show entries:</label>
                <select id="entries" name="entries" class="form-control" onchange="location = this.value;">
                    <option value="?entries=10" <?php echo e(request('entries') == 10 ? 'selected' : ''); ?>>10</option>
                    <option value="?entries=25" <?php echo e(request('entries') == 25 ? 'selected' : ''); ?>>25</option>
                    <option value="?entries=50" <?php echo e(request('entries') == 50 ? 'selected' : ''); ?>>50</option>
                    <option value="?entries=100" <?php echo e(request('entries') == 100 ? 'selected' : ''); ?>>100</option>
                </select>
            </div>
        </div>
    </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\01-focused\laravel-sil\resources\views/reagen/reagen_keluar.blade.php ENDPATH**/ ?>