


<?php $__env->startSection('main-content'); ?>
    <!-- Page Heading -->
<h1 class="h3 mb-4 text-gray-800"><?php echo e(__('Riwayat Pemeriksaan')); ?></h1>

<div class="row justify-content-center px-3">
    <div class="col-12 card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Data Riwayat Pemeriksaan</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th rowspan="2">No</th>
                            <th rowspan="2">Tanggal</th>
                            <th rowspan="2">No Lab</th>
                            <th rowspan="2">Grup Tes</th>
                            <th rowspan="2">Nama Pasien</th>
                            <th rowspan="2">Dokter</th>
                            <th colspan="5" class="text-center">Jenis Sample</th>
                            <th rowspan="2">Aksi</th>
                        </tr>
                        <tr>
                            <th>EDTA</th>
                            <th>Citrus</th>
                            <th>Serum</th>
                            <th>Urine</th>
                            <th>Lainnya</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $pasiens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pemeriksaan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($pemeriksaan->kode); ?></td>
                                <td><?php echo e($pemeriksaan->tgl_daftar); ?></td>
                                <td><?php echo e($pemeriksaan->no_lab); ?></td>
                                <td><?php echo e($pemeriksaan->group_test); ?></td>
                                <td><?php echo e($pemeriksaan->nama_pasien); ?></td>
                                <td><?php echo e($pemeriksaan->dokter); ?></td>                            
                                <td><?php echo e($pemeriksaan->jenis_pemeriksaan == 'EDTA' ? '✔' : ''); ?></td>
                                <td><?php echo e($pemeriksaan->jenis_pemeriksaan == 'Citrus' ? '✔' : ''); ?></td>
                                <td><?php echo e($pemeriksaan->jenis_pemeriksaan == 'Serum' ? '✔' : ''); ?></td>
                                <td><?php echo e($pemeriksaan->jenis_pemeriksaan == 'Urine' ? '✔' : ''); ?></td>
                                <td><?php echo e($pemeriksaan->jenis_pemeriksaan == 'Lainnya' ? '✔' : ''); ?></td>
                                <td>
                                  <a href="<?php echo e(route('daftar_pemeriksaan.edit', $pemeriksaan->id)); ?>" class="btn btn-secondary">
                                            <?php echo e($pemeriksaan->status_pemeriksaan); ?>

                                        </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\01-focused\laravel-sil\resources\views/pengambilan_sampel.blade.php ENDPATH**/ ?>