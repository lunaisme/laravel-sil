

<?php
$kalibrasiAlats = collect([
    (object)[
        'no' => 1,
        'kode_alat' => 'A001',
        'nama_alat' => 'Alat Ukur 1',
        'tgl_kalibrasi' => '2023-01-01',
        'status' => 'Kurang Optimal',
        'tgl_kalibrasi_ulang' => '2024-01-01'
    ],
    (object)[
        'no' => 2,
        'kode_alat' => 'A002',
        'nama_alat' => 'Alat Ukur 2',
        'tgl_kalibrasi' => '2023-02-01',
        'status' => 'Baik',
        'tgl_kalibrasi_ulang' => '2024-02-01'
    ]
]);
?>

<?php $__env->startSection('main-content'); ?>
    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?php echo e(__('Daftar Kalibrasi Alat')); ?></h1>

    <div class="row justify-content-center px-3">

    <div class="col-12 card shadow mb-4">
        <div class="card-header py-3 row">
            <h6 class="col m-0 font-weight-bold text-primary">Data Kalibrasi Alat</h6>
            <a href="" class="col-2 btn btn-primary btn-sm">
                <i class="fas fa-plus"></i> Tambah Data
            </a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Kode Alat</th>
                            <th>Nama Alat</th>
                            <th>Tanggal Kalibrasi</th>
                            <th>Status</th>
                            <th>Tanggal Kalibrasi Ulang</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $kalibrasiAlats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($alat->no); ?></td>
                                <td><?php echo e($alat->kode_alat); ?></td>
                                <td><?php echo e($alat->nama_alat); ?></td>
                                <td><?php echo e($alat->tgl_kalibrasi); ?></td>
                                <td>
                                    <?php if($alat->status == 'Baik'): ?>
                                        <span class="badge badge-success"><?php echo e($alat->status); ?></span>
                                    <?php elseif($alat->status == 'Kurang Optimal'): ?>
                                        <span class="badge badge-danger"><?php echo e($alat->status); ?></span>
                                    <?php elseif($alat->status == 'Menunggu'): ?>
                                        <span class="badge badge-warning"><?php echo e($alat->status); ?></span>
                                    <?php elseif($alat->status == 'Sedang Kalibrasi'): ?>
                                        <span class="badge badge-info"><?php echo e($alat->status); ?></span>
                                    <?php else: ?>
                                        <span class="badge badge-dark"><?php echo e($alat->status); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($alat->tgl_kalibrasi_ulang); ?></td>
                                <td>
                                    <a href="" class="btn btn-warning btn-sm">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\01-focused\laravel-sil\resources\views/stok_reagen.blade.php ENDPATH**/ ?>