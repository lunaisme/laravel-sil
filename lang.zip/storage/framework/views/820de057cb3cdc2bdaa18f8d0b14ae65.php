

<?php $__env->startSection('main-content'); ?>
<!-- Page Heading -->
<h1 class="h3 mb-4 text-gray-800"><?php echo e(__('Daftar Pemeriksaan - ')); ?><?php echo e($group); ?></h1>

<div class="row justify-content-center px-3">
    <div class="col-12 card shadow mb-4">
        <div class="card-header py-3 row">
            <h6 class="col m-0 font-weight-bold text-primary">Data Pemeriksaan</h6>
            <a href="<?php echo e(route('daftar_pemeriksaan.create')); ?>" class="col-2 btn btn-primary btn-sm">
                <i class="fas fa-plus"></i> Tambah Data
            </a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Kode</th>
                            <th>Nama</th>
                            <th>Jenis Kelamin</th>
                            <th>Tgl Daftar</th>
                            <th>Jenis Pemeriksaan</th>
                            <th>Jaminan</th>
                            <th>Dokter</th>
                            <th>No RM</th>
                            <th>Tgl Pemeriksaan</th>
                            <th>Pembayaran</th>
                            <th>Status Pemeriksaan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $pasiens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $pasien): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($index + 1); ?></td>
                                <td><?php echo e($pasien->kode); ?></td>
                                <td><?php echo e($pasien->nama_pasien); ?></td>
                                <td><?php echo e($pasien->jenis_kelamin); ?></td>
                                <td><?php echo e($pasien->tgl_daftar); ?></td>
                                <td><?php echo e($pasien->jenis_pemeriksaan); ?></td>
                                <td><?php echo e($pasien->jaminan); ?></td>
                                <td><?php echo e($pasien->dokter); ?></td>
                                <td><?php echo e($pasien->no_rm); ?></td>
                                <td><?php echo e($pasien->tgl_pemeriksaan); ?></td>
                                <td><?php echo e($pasien->pembayaran); ?></td>
                                <td><?php echo e($pasien->status_pemeriksaan); ?></td>
                                <td>
                                    <a href="<?php echo e(route('hasil_pemeriksaan.index', $pasien->id)); ?>" class="btn btn-warning btn-sm">Input Hasil</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\01-focused\laravel-sil\resources\views/daftar_pemeriksaan/group.blade.php ENDPATH**/ ?>