

<?php $__env->startSection('main-content'); ?>
<!-- Page Heading -->
<h1 class="h3 mb-4 text-gray-800"><?php echo e(__('Daftar Pemeriksaan')); ?></h1>

<div class="row justify-content-center px-3">
    <div class="col-12 card shadow mb-4">
        <div class="card-header py-3 row">
            <h6 class="col m-0 font-weight-bold text-primary">Data Pemeriksaan</h6>
            <a href="<?php echo e(route('patients.create')); ?>" class="col-2 btn btn-primary btn-sm">
            <i class="fas fa-plus"></i> Tambah Data
            </a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Kode</th>
                            <th>Nama</th>
                            <th>Jenis Kelamin</th>
                            <th>Tgl Daftar</th>
                            <th>Jenis Pemeriksaan</th>
                            <th>Jaminan</th>
                            <th>Dokter</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if($patients->isEmpty()): ?>
                                <tr>
                                    <td colspan="9" class="text-center">Tidak ada data pasien.</td>
                                </tr>
                            <?php else: ?>
                        <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($index + 1); ?></td>
                                <td><?php echo e($patient->kode); ?></td>
                                <td><?php echo e($patient->nama); ?></td>
                                <td><?php echo e($patient->jenis_kelamin); ?></td>
                                <td><?php echo e($patient->tgl_daftar); ?></td>
                                <td><?php echo e($patient->jenis_pemeriksaan); ?></td>
                                <td><?php echo e($patient->jaminan); ?></td>
                                <td><?php echo e($patient->dokter); ?></td>
                                <td>
                                    <a href="<?php echo e(route('patients.show', $patient->id)); ?>">Detail</a>
                                    <form action="<?php echo e(route('patients.accept', $patient->id)); ?>" method="POST" style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit">Terima</button>
                                    </form>
                                    <form action="<?php echo e(route('patients.reject', $patient->id)); ?>" method="POST" style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit">Tolak</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\01-focused\laravel-sil\resources\views/patients/index.blade.php ENDPATH**/ ?>