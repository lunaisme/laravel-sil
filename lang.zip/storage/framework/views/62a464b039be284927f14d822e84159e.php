<?php echo e($slot); ?>

<?php /**PATH D:\01-focused\laravel-sil\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>