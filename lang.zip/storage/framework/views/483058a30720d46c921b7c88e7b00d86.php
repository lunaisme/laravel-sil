

<?php $__env->startSection('main-content'); ?>
<h1 class="h3 mb-4 text-gray-800">Input Hasil Pemeriksaan: <?php echo e($pasien->id); ?></h1>

<div class="card shadow mb-4">
    <div class="card-header">
        <h6 class="m-0 font-weight-bold text-primary">Detail Pasien</h6>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-md-6">
                <div class="card shadow mb-4">
                    <div class="card-header">
                        <h6 class="m-0 font-weight-bold text-primary">Informasi Pasien</h6>
                    </div>
                    <div class="card-body">
                        <p><strong>No RM:</strong> <?php echo e($pasien->no_rm); ?></p>
                        <p><strong>Nama Pasien:</strong> <?php echo e($pasien->nama_pasien); ?></p>
                        <p><strong>Tanggal Lahir:</strong> <?php echo e($pasien->tgl_lahir); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card shadow mb-4">
                    <div class="card-header">
                        <h6 class="m-0 font-weight-bold text-primary">Informasi Pemeriksaan</h6>
                    </div>
                    <div class="card-body">
                        <p><strong>No Lab:</strong> <?php echo e($pasien->no_lab); ?></p>
                        <p><strong>Tanggal Pemeriksaan:</strong> <?php echo e($pasien->tgl_pemeriksaan); ?></p>
                        <p><strong>Dokter:</strong> <?php echo e($pasien->dokter); ?></p>
                    </div>
                </div>
            </div>
        </div>
        <form action="<?php echo e(route('hasil_pemeriksaan.store', $pasien->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div id="hasil-pemeriksaan-form">
                <div class="form-row mb-3">
                    <div class="col">
                        <input type="text" name="hasil_pemeriksaan[0][parameter]" class="form-control" placeholder="Parameter" required>
                    </div>
                    <div class="col">
                        <input type="text" name="hasil_pemeriksaan[0][hasil]" class="form-control" placeholder="Hasil" required>
                    </div>
                    <div class="col">
                        <input type="text" name="hasil_pemeriksaan[0][satuan]" class="form-control" placeholder="Satuan" required>
                    </div>
                    <div class="col">
                        <input type="text" name="hasil_pemeriksaan[0][nilai_rujukan]" class="form-control" placeholder="Nilai Rujukan" required>
                    </div>
                    <div class="col">
                        <input type="text" name="hasil_pemeriksaan[0][metode]" class="form-control" placeholder="Metode">
                    </div>
                    <div class="col">
                        <select name="hasil_pemeriksaan[0][status]" class="form-control" required>
                            <option value="Normal">Normal</option>
                            <option value="Abnormal">Abnormal</option>
                        </select>
                    </div>
                </div>
            </div>
            <button type="button" id="add-row" class="btn btn-sm btn-secondary mb-3">Tambah Baris</button>
            <button type="submit" class="btn btn-primary">Simpan</button>
        </form>
    </div>
</div>

<?php if($pasien->hasilPemeriksaan->isNotEmpty()): ?>
<div class="card shadow mt-4">
    <div class="card-header">
        <h6 class="m-0 font-weight-bold text-primary">Riwayat Hasil Pemeriksaan</h6>
    </div>
    <div class="card-body">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Parameter</th>
                    <th>Hasil</th>
                    <th>Satuan</th>
                    <th>Nilai Rujukan</th>
                    <th>Metode</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $pasien->hasilPemeriksaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hasil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($hasil->parameter); ?></td>
                        <td><?php echo e($hasil->hasil); ?></td>
                        <td><?php echo e($hasil->satuan); ?></td>
                        <td><?php echo e($hasil->nilai_rujukan); ?></td>
                        <td><?php echo e($hasil->metode); ?></td>
                        <td><?php echo e($hasil->status); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<script>
    let rowIndex = 1;
    document.getElementById('add-row').addEventListener('click', () => {
        const form = document.getElementById('hasil-pemeriksaan-form');
        const newRow = `
            <div class="form-row mb-3">
                <div class="col">
                    <input type="text" name="hasil_pemeriksaan[${rowIndex}][parameter]" class="form-control" placeholder="Parameter" required>
                </div>
                <div class="col">
                    <input type="text" name="hasil_pemeriksaan[${rowIndex}][hasil]" class="form-control" placeholder="Hasil" required>
                </div>
                <div class="col">
                    <input type="text" name="hasil_pemeriksaan[${rowIndex}][satuan]" class="form-control" placeholder="Satuan" required>
                </div>
                <div class="col">
                    <input type="text" name="hasil_pemeriksaan[${rowIndex}][nilai_rujukan]" class="form-control" placeholder="Nilai Rujukan" required>
                </div>
                <div class="col">
                    <input type="text" name="hasil_pemeriksaan[${rowIndex}][metode]" class="form-control" placeholder="Metode">
                </div>
                <div class="col">
                    <select name="hasil_pemeriksaan[${rowIndex}][status]" class="form-control" required>
                        <option value="Normal">Normal</option>
                        <option value="Abnormal">Abnormal</option>
                    </select>
                </div>
            </div>
        `;
        form.insertAdjacentHTML('beforeend', newRow);
        rowIndex++;
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\01-focused\laravel-sil\resources\views/hasil_pemeriksaan/index.blade.php ENDPATH**/ ?>