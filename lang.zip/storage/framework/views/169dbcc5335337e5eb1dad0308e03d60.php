

<?php $__env->startSection('main-content'); ?>
    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?php echo e(__('Riwayat Pemeriksaan')); ?></h1>
    <?php if(session('success')): ?>
        <div class="alert alert-success border-left-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger border-left-danger" role="alert">
            <ul class="pl-4 my-2">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <div class="row justify-content-center px-3">

    <div class="col-12 card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Data Riwayat Pemeriksaan</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Tanggal</th>
                            <th>No Lab</th>
                            <th>Grup Tes</th>
                            <th>Nama Pasien</th>
                            <th>Dokter</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $pasiens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pasien): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($pasien->kode); ?></td>
                                <td><?php echo e($pasien->tgl_pemeriksaan); ?></td>
                                <td><?php echo e($pasien->no_lab); ?></td>
                                <td><?php echo e($pasien->group_test); ?></td>
                                <td><?php echo e($pasien->nama_pasien); ?></td>
                                <td><?php echo e($pasien->dokter); ?></td>
                                <td>
                                    <span class="badge <?php echo e($pasien->status_pemeriksaan == 'Validasi' ? 'badge-danger' : 'badge-success'); ?>">
                                        <?php echo e($pasien->status_pemeriksaan); ?>

                                    </span>
                                </td>
                                <td>
                                    <a href="" class="btn btn-info btn-sm" ><i class="fas fa-eye"></i></a>
                                    <a href="<?php echo e(route('updateStatus', $pasien->id)); ?>" class="btn btn-success btn-sm"><i class="fas fa-check"></i></a>
                                    <a href="<?php echo e(route('hasil_pemeriksaan.print', $pasien->id)); ?>" class="fas fa-print" target="_blank"></a>
                                    <a href="" class="btn btn-warning btn-sm"><i class="fas fa-paper-plane"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\01-focused\laravel-sil\resources\views/riwayat_pemeriksaan.blade.php ENDPATH**/ ?>