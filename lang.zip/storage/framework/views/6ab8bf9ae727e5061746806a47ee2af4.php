

<?php $__env->startSection('main-content'); ?>
    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?php echo e(__('Data Reagen')); ?></h1>

    <div class="row justify-content-center px-3">
        <div class="col-12 card shadow mb-4">
            <div class="card-header py-3 row">
                <h6 class="col m-0 font-weight-bold text-primary">Data Stock Reagen</h6>
                <a href="<?php echo e(route('stok_reagen.create')); ?>" class="col-2 btn btn-primary btn-sm">
                    <i class="fas fa-plus"></i> Tambah Data
                </a>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead class="thead-light">
                            <tr>
                                <th>Kode</th>
                                <th>Nama</th>
                                <th>Stok Awal</th>
                                <th>Masuk</th>
                                <th>Keluar</th>
                                <th>Stok Akhir</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($dataReagens->isEmpty()): ?>
                                <tr>
                                    <td colspan="6" class="text-center">Tidak ada data reagen.</td>
                                </tr>
                            <?php else: ?>
                                <?php $__currentLoopData = $dataReagens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reagen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($reagen['kode']); ?></td>
                                        <td><?php echo e($reagen['nama']); ?></td>
                                        <td><?php echo e($reagen['stok_awal']); ?></td>
                                        <td><?php echo e($reagen['masuk']); ?></td>
                                        <td><?php echo e($reagen['keluar']); ?></td>
                                        <td><?php echo e($reagen['stok_akhir']); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\01-focused\laravel-sil\resources\views/reagen/stok_reagen.blade.php ENDPATH**/ ?>