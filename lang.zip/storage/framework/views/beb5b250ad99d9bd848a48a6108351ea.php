

<?php $__env->startSection('main-content'); ?>
    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?php echo e(__('Edit Kalibrasi')); ?></h1>

    <div class="row">
        <div class="col-lg-8 order-lg-1">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Form Edit Kalibrasi</h6>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('kalibrasi.update', $kalibrasi)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="form-group">
                            <label>Kode Alat</label>
                            <input type="text" name="kode_alat" class="form-control" value="<?php echo e($kalibrasi->kode_alat); ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Nama Alat</label>
                            <input type="text" name="nama_alat" class="form-control" value="<?php echo e($kalibrasi->nama_alat); ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Tanggal Kalibrasi</label>
                            <input type="date" name="tanggal_kalibrasi" class="form-control" value="<?php echo e($kalibrasi->tanggal_kalibrasi); ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Status</label>
                            <select name="status" class="form-control" required>
                                <option value="kurang optimal" <?php echo e($kalibrasi->status == 'kurang optimal' ? 'selected' : ''); ?>>Kurang Optimal</option>
                                <option value="menunggu proses" <?php echo e($kalibrasi->status == 'menunggu proses' ? 'selected' : ''); ?>>Menunggu Proses</option>
                                <option value="sedang proses" <?php echo e($kalibrasi->status == 'sedang proses' ? 'selected' : ''); ?>>Sedang Proses</option>
                                <option value="baik" <?php echo e($kalibrasi->status == 'baik' ? 'selected' : ''); ?>>Baik</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Catatan</label>
                            <textarea name="catatan" class="form-control" required><?php echo e($kalibrasi->catatan); ?></textarea>
                        </div>
                        <div class="d-flex justify-content-end">
                            <a href="<?php echo e(route('kalibrasi.index')); ?>" class="btn btn-secondary mr-2">Cancel</a>
                            <button type="submit" class="btn btn-success">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\01-focused\laravel-sil\resources\views/kalibrasi/edit.blade.php ENDPATH**/ ?>