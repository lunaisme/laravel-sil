

<?php $__env->startSection('main-content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-xl-6 col-lg-12 col-md-9">
            <div class="card o-hidden border-0 shadow-lg my-5" style="background-color: rgba(255, 255, 255, 0.8);">
                <div class="card-body p-0">
                    <div class="row justify-content-center">
                        <div class="col-lg-12">
                            <div class="p-5">
                                    <?php if (isset($component)) { $__componentOriginald9c8b3e442540e82460e1ecc7d5f880b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald9c8b3e442540e82460e1ecc7d5f880b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.kemenkes-logo','data' => ['class' => 'img-fluid mx-auto d-block']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('kemenkes-logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'img-fluid mx-auto d-block']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald9c8b3e442540e82460e1ecc7d5f880b)): ?>
<?php $attributes = $__attributesOriginald9c8b3e442540e82460e1ecc7d5f880b; ?>
<?php unset($__attributesOriginald9c8b3e442540e82460e1ecc7d5f880b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald9c8b3e442540e82460e1ecc7d5f880b)): ?>
<?php $component = $__componentOriginald9c8b3e442540e82460e1ecc7d5f880b; ?>
<?php unset($__componentOriginald9c8b3e442540e82460e1ecc7d5f880b); ?>
<?php endif; ?>
                                <div class="text-center">
                                    <h1 class="h3 text-gray-900 font-weight-bold mb-4 mt-0"><?php echo e(__('SISTEM INFORMASI LABORATORIUM RSUD SENOPATI')); ?></h1>
                                </div>

                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger border-left-danger" role="alert">
                                        <ul class="pl-4 my-2">
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>

                                <form method="POST" action="<?php echo e(route('login')); ?>" class="user">
                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

                                    <div class="form-group">
                                        <input type="email" class="form-control form-control-user" name="email" placeholder="<?php echo e(__('E-Mail Address')); ?>" value="<?php echo e(old('email')); ?>" required autofocus>
                                    </div>

                                    <div class="form-group">
                                        <input type="password" class="form-control form-control-user" name="password" placeholder="<?php echo e(__('Password')); ?>" required>
                                    </div>
                                    <div class="form-group">
                                        <label for="role">Login Sebagai</label>
                                        <select class="form-control rounded-pill" name="role" id="role" required>
                                            <option value="admin" <?php echo e(old('role') == 'admin' ? 'selected' : ''); ?>>Admin</option>
                                            <option value="atlm" <?php echo e(old('role') == 'atlm' ? 'selected' : ''); ?>>ATLM</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <div class="custom-control custom-checkbox small">
                                            <input type="checkbox" class="custom-control-input" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                            <label class="custom-control-label" for="remember"><?php echo e(__('Remember Me')); ?></label>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <button type="submit" class="btn btn-primary btn-user btn-block">
                                            <?php echo e(__('Login')); ?>

                                        </button>
                                    </div>
                                </form>

                                <hr>
                                <div class="d-flex justify-content-between">
                                    <?php if(Route::has('password.request')): ?>
                                    <div class="text-start">
                                        <a class="small" href="<?php echo e(route('password.request')); ?>">
                                            <?php echo e(__('Forgot Password?')); ?>

                                        </a>
                                    </div>
                                    <?php endif; ?>

                                    <?php if(Route::has('register')): ?>
                                    <div class="text-end ms-auto">
                                        <a class="small" href="<?php echo e(route('register')); ?>"><?php echo e(__('Create an Account!')); ?></a>
                                    </div>
                                    <?php endif; ?>
                                </div>  
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\01-focused\laravel-sil\resources\views/auth/login.blade.php ENDPATH**/ ?>